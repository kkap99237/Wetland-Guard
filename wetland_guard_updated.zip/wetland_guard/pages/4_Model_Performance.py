"""
pages/4_Model_Performance.py
Machine Learning Model Performance, Evaluation Metrics,
Confusion Matrices, and Feature Importance Breakdown.
"""
import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.figure_factory as ff
import json
import os

from src.dashboard_utils import get_models
from src.ui_theme import apply_custom_css, render_header, render_sidebar, get_plotly_theme

st.set_page_config(page_title="Model Performance | Wetland Guard", page_icon="📊", layout="wide")

# Apply enterprise styling
apply_custom_css()
render_sidebar()

# Page Executive Header
render_header(
    title="Machine Learning Performance & Validation",
    subtitle="Chronological Temporal Split, Random Forest vs Logistic Baseline, and Interpretability Breakdown",
    tag="ML Validation & Model Cards"
)

# Mandatory Scientific Disclaimer Card
st.markdown("""
<div class="wg-callout-card" style="border-left-color: #b45309; background: #fffbeb; margin-bottom: 1.5rem;">
    <div class="wg-callout-title" style="color: #92400e;">
        <span>⚠️</span> Scientific Methodology & Retrospective Weak-Label Disclaimer
    </div>
    <div class="wg-callout-text" style="color: #78350f;">
        Model performance is benchmarked against <b>retrospective weak/derived heuristic screening targets</b> 
        (multi-sensor persistent deterioration rules) and must <b>NOT be interpreted as conservation-grade predictive ground truth</b>.
        The high classification scores demonstrate that the Random Forest model faithfully synthesizes the multi-sensor heuristic rules;
        they do not replace physical field verification or legal hydrological demarcation.
    </div>
</div>
""", unsafe_allow_html=True)

rf_data, lr_data, metadata = get_models()

if not metadata:
    st.error("Model metadata not found. Run train_model.py first.")
    st.stop()

rf_m = metadata.get("random_forest_metrics", {})
lr_m = metadata.get("logistic_baseline_metrics", {})

# Dataset Splits Summary
st.markdown("""
<div class="wg-section-title">
    <span>⏳</span> Chronological Data Split Strategy (Zero Future Leakage)
</div>
<div class="wg-section-subtitle">
    Observations are strictly partitioned across time to evaluate temporal generalisation on future unobserved monthly cycles:
</div>
""", unsafe_allow_html=True)

col_s1, col_s2, col_s3, col_s4 = st.columns(4)

with col_s1:
    st.markdown(f"""
    <div class="wg-metric-card">
        <div class="wg-metric-label">Total Observations <span>📁</span></div>
        <div class="wg-metric-value">{metadata.get('total_observations', 720):,}</div>
        <div class="wg-metric-subtext"><span class="wg-delta-chip wg-delta-neutral">15 Wetlands</span> × 48 Months</div>
    </div>
    """, unsafe_allow_html=True)

with col_s2:
    st.markdown(f"""
    <div class="wg-metric-card">
        <div class="wg-metric-label">Training Set (70%) <span>🏋️</span></div>
        <div class="wg-metric-value">{metadata.get('train_samples', 503)}</div>
        <div class="wg-metric-subtext"><span class="wg-delta-chip wg-delta-neutral">2021-01 to 2023-10</span> Baselines</div>
    </div>
    """, unsafe_allow_html=True)

with col_s3:
    st.markdown(f"""
    <div class="wg-metric-card">
        <div class="wg-metric-label">Validation Set (15%) <span>🎯</span></div>
        <div class="wg-metric-value">{metadata.get('val_samples', 109)}</div>
        <div class="wg-metric-subtext"><span class="wg-delta-chip wg-delta-warning">2023-10 to 2024-05</span> Tuning</div>
    </div>
    """, unsafe_allow_html=True)

with col_s4:
    st.markdown(f"""
    <div class="wg-metric-card">
        <div class="wg-metric-label">Test Set (15%) <span>🧪</span></div>
        <div class="wg-metric-value">{metadata.get('test_samples', 108)}</div>
        <div class="wg-metric-subtext"><span class="wg-delta-chip wg-delta-success">2024-05 to 2024-12</span> Holdout</div>
    </div>
    """, unsafe_allow_html=True)

st.markdown("<br>", unsafe_allow_html=True)

# Comparative Metrics Table
st.markdown("""
<div class="wg-section-title">
    <span>⚖️</span> Comparative Evaluation: Random Forest vs Logistic Regression Baseline
</div>
""", unsafe_allow_html=True)

comp_df = pd.DataFrame([
    {
        "Model": "Random Forest Classifier",
        "Architecture": "200 Estimators, class_weight='balanced'",
        "Accuracy": rf_m.get("accuracy", 0.99),
        "Precision": rf_m.get("precision", 0.96),
        "Recall": rf_m.get("recall", 1.00),
        "F1-Score": rf_m.get("f1_score", 0.98),
        "ROC-AUC": rf_m.get("roc_auc", 0.999)
    },
    {
        "Model": "Logistic Regression (Linear Baseline)",
        "Architecture": "StandardScaler, L2 Penalty, balanced",
        "Accuracy": lr_m.get("accuracy", 0.97),
        "Precision": lr_m.get("precision", 0.89),
        "Recall": lr_m.get("recall", 1.00),
        "F1-Score": lr_m.get("f1_score", 0.94),
        "ROC-AUC": lr_m.get("roc_auc", 0.990)
    }
])

st.table(comp_df.style.format({
    "Accuracy": "{:.2%}",
    "Precision": "{:.2%}",
    "Recall": "{:.2%}",
    "F1-Score": "{:.4f}",
    "ROC-AUC": "{:.4f}"
}))

st.markdown("<br>", unsafe_allow_html=True)

# Visualizations: Confusion Matrix and Feature Importance
col_left, col_right = st.columns([1, 1])
plotly_theme = get_plotly_theme()

with col_left:
    st.markdown("""
    <div class="wg-section-title" style="margin-top: 0;">
        <span>🎯</span> Chronological Test Set Confusion Matrix
    </div>
    """, unsafe_allow_html=True)

    cm = rf_m.get("confusion_matrix", [[83, 1], [0, 24]])
    z = [[cm[0][0], cm[0][1]], [cm[1][0], cm[1][1]]]
    x = ["Predicted Normal (0)", "Predicted Risk (1)"]
    y = ["Actual Normal (0)", "Actual Risk (1)"]
    
    fig_cm = ff.create_annotated_heatmap(
        z, x=x, y=y,
        colorscale="Blues",
        showscale=True
    )
    fig_cm.update_layout(
        **plotly_theme,
        title=dict(text="Random Forest Test Confusion Matrix", font=dict(size=14, weight=700)),
        height=380,
        margin=dict(l=40, r=40, t=50, b=40)
    )
    st.plotly_chart(fig_cm, use_container_width=True)

with col_right:
    st.markdown("""
    <div class="wg-section-title" style="margin-top: 0;">
        <span>📊</span> Random Forest Gini Feature Importances
    </div>
    """, unsafe_allow_html=True)

    imp_path = "outputs/feature_importances.csv"
    if os.path.exists(imp_path):
        imp_df = pd.read_csv(imp_path).sort_values("importance", ascending=True)
        fig_imp = px.bar(
            imp_df,
            x="importance",
            y="feature",
            orientation="h",
            color="importance",
            color_continuous_scale="Viridis",
            labels={"importance": "Gini Importance", "feature": "Engineered Predictor"}
        )
        fig_imp.update_layout(
            **plotly_theme,
            title=dict(text="Global Predictor Contribution", font=dict(size=14, weight=700)),
            height=380,
            margin=dict(l=40, r=40, t=50, b=40),
            coloraxis_showscale=False
        )
        st.plotly_chart(fig_imp, use_container_width=True)

st.markdown("<br>", unsafe_allow_html=True)

# Labeling Rule Formulation
st.markdown("""
<div class="wg-section-title">
    <span>📜</span> Retrospective Weak-Supervision Heuristic Rules
</div>
<div style="background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.25rem; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 14px;">
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px;">
            <div style="font-weight: 700; font-size: 0.85rem; color: #065f46; margin-bottom: 6px;">Rule 1: Coupled Multi-Sensor Persistence</div>
            <div style="font-size: 0.8rem; color: #475569; line-height: 1.5;">
                Simultaneous decline in vegetation vigor and surface moisture (<code>multi_indicator_decline == 1</code>) sustained across <b>≥ 2 consecutive months</b>.
            </div>
        </div>
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px;">
            <div style="font-weight: 700; font-size: 0.85rem; color: #0284c7; margin-bottom: 6px;">Rule 2: Coupled Spectral Anomalies</div>
            <div style="font-size: 0.8rem; color: #475569; line-height: 1.5;">
                Severe concurrent departures from baseline in both surface water (<code>MNDWI_anomaly &lt; -1.2σ</code>) and canopy vigor (<code>NDVI_anomaly &lt; -1.0σ</code>).
            </div>
        </div>
        <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px;">
            <div style="font-weight: 700; font-size: 0.85rem; color: #b45309; margin-bottom: 6px;">Rule 3: Radar & Shoreline Loss</div>
            <div style="font-size: 0.8rem; color: #475569; line-height: 1.5;">
                Water spread contraction <b>&gt; 25%</b> accompanied by Sentinel-1 radar backscatter drop <b>&gt; 1.0 dB</b> (drainage or vegetative desiccation).
            </div>
        </div>
    </div>
</div>
""", unsafe_allow_html=True)
