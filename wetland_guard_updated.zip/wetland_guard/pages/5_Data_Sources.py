"""
pages/5_Data_Sources.py
Official Data Sources, Sensor Specifications, Clickable URLs,
and Comprehensive Scientific Limitations.
"""
import streamlit as st
from src.ui_theme import apply_custom_css, render_header, render_sidebar

st.set_page_config(page_title="Data Sources | Wetland Guard", page_icon="📚", layout="wide")

# Apply enterprise styling
apply_custom_css()
render_sidebar()

# Page Executive Header
render_header(
    title="Real-World Data Sources & Scientific Limitations",
    subtitle="Provenance, Satellite Sensor Specifications, Official Citations, and Remote Sensing Operational Caveats",
    tag="Data Governance & Limitations"
)

st.markdown("""
<div class="wg-section-title">
    <span>🛰️</span> Primary Earth Observation & Geospatial Reference Datasets
</div>
<div class="wg-section-subtitle">
    Authoritative remote sensing missions and GIS inventories powering the Tamil Nadu wetland monitoring observatory:
</div>
""", unsafe_allow_html=True)

# 1. ISRO SAC VEDAS NWIA
with st.expander("1. ISRO / SAC VEDAS National Wetland Inventory & Assessment (NWIA)", expanded=True):
    st.markdown(r"""
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 8px;">
        <div style="display: flex; gap: 8px; margin-bottom: 6px;">
            <span style="background: #e0f2fe; color: #0369a1; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 12px;">GIS INVENTORY</span>
            <span style="background: #f1f5f9; color: #475569; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px;">1:50,000 SCALE</span>
            <span style="background: #ecfdf5; color: #065f46; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px;">TAMIL NADU ATLAS</span>
        </div>
        <ul style="font-size: 0.85rem; color: #334155; line-height: 1.6; margin: 0; padding-left: 1.2rem;">
            <li><b>Agency / Provider:</b> Space Applications Centre (SAC), Indian Space Research Organisation (ISRO), Ahmedabad.</li>
            <li><b>Official Portal:</b> <a href="https://vedas.sac.gov.in/en/National_Wetland_Inventory_and_Assessment_(NWIA)_Atlas.html" target="_blank">ISRO VEDAS National Wetland Inventory & Assessment Atlas</a></li>
            <li><b>Contribution:</b> Ground-verified wetland boundary polygons, baseline surface area (hectares), wetland typology (e.g. inland freshwater tank, coastal lagoon, mangrove estuary), and official Ramsar designations.</li>
            <li><b>Role in Wetland Guard:</b> Forms the foundational study area geometries across all 15 priority monitored sites in Tamil Nadu.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

# 2. Copernicus Sentinel-2
with st.expander("2. Copernicus Sentinel-2 MultiSpectral Instrument (MSI Level-2A Surface Reflectance)", expanded=True):
    st.markdown(r"""
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 8px;">
        <div style="display: flex; gap: 8px; margin-bottom: 6px;">
            <span style="background: #dcfce7; color: #166534; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 12px;">OPTICAL MULTISPECTRAL</span>
            <span style="background: #f1f5f9; color: #475569; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px;">10m / 20m RESOLUTION</span>
            <span style="background: #f1f5f9; color: #475569; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px;">5-DAY REVISIT</span>
        </div>
        <ul style="font-size: 0.85rem; color: #334155; line-height: 1.6; margin: 0; padding-left: 1.2rem;">
            <li><b>Provider:</b> European Space Agency (ESA) / European Commission Copernicus Programme.</li>
            <li><b>Product Identifier:</b> <code>COPERNICUS/S2_SR_HARMONIZED</code> (Bottom-of-Atmosphere Surface Reflectance).</li>
            <li><b>Official Catalog:</b> <a href="https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S2_SR_HARMONIZED" target="_blank">Google Earth Engine Sentinel-2 SR Harmonized</a></li>
            <li><b>Bands Utilized:</b>
                <ul>
                    <li><b>B2 (Blue - 490 nm, 10m):</b> Atmospheric and aerosol scattering correction in EVI.</li>
                    <li><b>B3 (Green - 560 nm, 10m):</b> Peak green reflectance for open-water discrimination (MNDWI / AWEI).</li>
                    <li><b>B4 (Red - 665 nm, 10m):</b> Chlorophyll absorption band for canopy vigor (NDVI / EVI).</li>
                    <li><b>B8 (NIR - 842 nm, 10m):</b> Strong vegetative mesophyll reflection and sharp water boundary delineation.</li>
                    <li><b>B11 (SWIR1 - 1610 nm, 20m):</b> Deep water absorption and soil moisture sensitivity.</li>
                    <li><b>B12 (SWIR2 - 2190 nm, 20m):</b> Automated water extraction index (AWEI).</li>
                    <li><b>QA60 (Cloud Mask):</b> Bit 10 (Opaque Cloud) and Bit 11 (Cirrus) cloud-screening mask.</li>
                </ul>
            </li>
            <li><b>Formulas Implemented:</b>
                $$\text{NDVI} = \frac{\text{NIR} - \text{RED}}{\text{NIR} + \text{RED}}$$
                $$\text{MNDWI} = \frac{\text{GREEN} - \text{SWIR1}}{\text{GREEN} + \text{SWIR1}}$$
                $$\text{EVI} = 2.5 \times \frac{\text{NIR} - \text{RED}}{\text{NIR} + 6.0\,\text{RED} - 7.5\,\text{BLUE} + 1.0}$$
                $$\text{AWEI}_{\text{nsh}} = 4.0 \times (\text{GREEN} - \text{SWIR1}) - (0.25 \times \text{NIR} + 2.75 \times \text{SWIR2})$$
            </li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

# 3. Copernicus Sentinel-1
with st.expander("3. Copernicus Sentinel-1 C-Band Synthetic Aperture Radar (SAR GRD)", expanded=True):
    st.markdown(r"""
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 8px;">
        <div style="display: flex; gap: 8px; margin-bottom: 6px;">
            <span style="background: #fee2e2; color: #991b1b; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 12px;">ACTIVE MICROWAVE (SAR)</span>
            <span style="background: #f1f5f9; color: #475569; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px;">ALL-WEATHER / CLOUD PENETRATING</span>
            <span style="background: #f1f5f9; color: #475569; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px;">10m SPATIAL RESOLUTION</span>
        </div>
        <ul style="font-size: 0.85rem; color: #334155; line-height: 1.6; margin: 0; padding-left: 1.2rem;">
            <li><b>Provider:</b> European Space Agency (ESA).</li>
            <li><b>Product Identifier:</b> <code>COPERNICUS/S1_GRD</code> (Ground Range Detected, interferometric wide swath).</li>
            <li><b>Official Catalog:</b> <a href="https://developers.google.com/earth-engine/datasets/catalog/COPERNICUS_S1_GRD" target="_blank">Google Earth Engine Sentinel-1 GRD</a></li>
            <li><b>Polarizations Utilized:</b> Dual-polarization VV (vertical transmit / vertical receive) and VH (cross-polarization).</li>
            <li><b>SAR Temporal Change Metric:</b> First difference $\Delta \text{SAR}_{\text{VV}}(t) = \text{SAR}_{\text{VV}}(t) - \text{SAR}_{\text{VV}}(t-1)$.</li>
            <li><b>Contribution:</b> Unhindered observation during monsoon cloud-cover; penetrates cloud decks to register changes in soil wetness and emergent vegetation volume scattering.</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

# 4. JRC Global Surface Water
with st.expander("4. JRC Global Surface Water (GSW)", expanded=True):
    st.markdown(r"""
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 8px;">
        <div style="display: flex; gap: 8px; margin-bottom: 6px;">
            <span style="background: #e0f2fe; color: #0369a1; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 12px;">HISTORICAL INUNDATION</span>
            <span style="background: #f1f5f9; color: #475569; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px;">38-YEAR BASELINE</span>
        </div>
        <ul style="font-size: 0.85rem; color: #334155; line-height: 1.6; margin: 0; padding-left: 1.2rem;">
            <li><b>Provider:</b> European Commission Joint Research Centre (JRC).</li>
            <li><b>Product Identifier:</b> <code>JRC/GSW1_4/GlobalSurfaceWater</code>.</li>
            <li><b>Official Catalog:</b> <a href="https://developers.google.com/earth-engine/datasets/catalog/JRC_GSW1_4_GlobalSurfaceWater" target="_blank">Google Earth Engine JRC Global Surface Water</a></li>
            <li><b>Metrics Extracted:</b> Water Occurrence (historical inundation frequency %) and Water Recurrence (inter-annual return probability).</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

# 5. NASA GLDAS-2.1
with st.expander("5. NASA GLDAS-2.1 / Noah Land Surface Model", expanded=True):
    st.markdown(r"""
    <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 8px;">
        <div style="display: flex; gap: 8px; margin-bottom: 6px;">
            <span style="background: #fef3c7; color: #92400e; font-size: 0.72rem; font-weight: 700; padding: 2px 8px; border-radius: 12px;">HYDROLOGICAL MODEL</span>
            <span style="background: #f1f5f9; color: #475569; font-size: 0.72rem; font-weight: 600; padding: 2px 8px; border-radius: 12px;">0.25° GRID</span>
        </div>
        <ul style="font-size: 0.85rem; color: #334155; line-height: 1.6; margin: 0; padding-left: 1.2rem;">
            <li><b>Provider:</b> NASA Goddard Earth Sciences Data and Information Services Center (GES DISC).</li>
            <li><b>Product Identifier:</b> <code>NASA/GLDAS/V021/NOAH/G025/T3H</code>.</li>
            <li><b>Official Catalog:</b> <a href="https://developers.google.com/earth-engine/datasets/catalog/NASA_GLDAS_V021_NOAH_G025_T3H" target="_blank">Google Earth Engine GLDAS-2.1 Noah</a></li>
            <li><b>Feature Extracted:</b> Volumetric Soil Moisture ($0–10\,\text{cm}$ root-zone layer in $\text{m}^3/\text{m}^3$).</li>
        </ul>
    </div>
    """, unsafe_allow_html=True)

st.markdown("---")

# Scientific Limitations Card
st.markdown("""
<div class="wg-section-title">
    <span>⚖️</span> Comprehensive Scientific Limitations & Operational Scope
</div>
<div style="background: white; border: 1px solid #e2e8f0; border-radius: 12px; padding: 1.4rem; box-shadow: 0 1px 3px rgba(0,0,0,0.04);">
    <div style="font-size: 0.85rem; color: #334155; line-height: 1.65;">
        <ol style="margin: 0; padding-left: 1.2rem;">
            <li style="margin-bottom: 8px;">
                <b>Remote-Sensing Indices are Physical Proxies:</b> Spectral indices (NDVI, MNDWI, EVI) register optical surface reflectance and absorption. They serve as valuable ecological proxies for canopy chlorophyll and open-water absorption, but cannot replace in-situ biochemical, water quality, or dissolved oxygen testing.
            </li>
            <li style="margin-bottom: 8px;">
                <b>Seasonal Phenology vs Anthropogenic Degradation:</b> In monsoonal climates like Tamil Nadu, severe dry-season desiccation (e.g. in May–June) causes natural water spread contraction that can mimic anthropogenic drying. Expanding seasonal baseline standardization (z-scores) mitigates but cannot completely decouple extreme meteorological drought from habitat degradation.
            </li>
            <li style="margin-bottom: 8px;">
                <b>Cloud Contamination & Optical Gaps:</b> Intense Northeast Monsoon rainfall periods (October–December) introduce heavy cloud cover. While Sentinel-1 SAR provides cloud-penetrating radar observations, optical indices may experience missing passes or reduced data quality confidence.
            </li>
            <li style="margin-bottom: 8px;">
                <b>SAR Surface Roughness & Geometric Sensitivity:</b> Calm standing water creates specular reflection (low backscatter), whereas windy choppy water or emergent reed beds can produce double-bounce scattering (elevated backscatter).
            </li>
            <li style="margin-bottom: 8px;">
                <b>Retrospective Weak Labels are Not Conservation Ground Truth:</b> The ML classification target is derived algorithmically from multi-sensor persistent deterioration criteria. It is a decision-support heuristic, not legal adjudication.
            </li>
            <li>
                <b>Operational Decision-Support Scope:</b> Wetland Guard is designed to <b>prioritise and dispatch field inspection teams</b>. A high risk score indicates an acute departure from historical baseline behavior requiring immediate ground verification.
            </li>
        </ol>
    </div>
</div>
""", unsafe_allow_html=True)
